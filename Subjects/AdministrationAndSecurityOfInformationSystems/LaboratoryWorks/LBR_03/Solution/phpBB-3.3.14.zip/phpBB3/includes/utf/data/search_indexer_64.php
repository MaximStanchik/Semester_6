<?php return array('𠀀'=>'𠀀');
